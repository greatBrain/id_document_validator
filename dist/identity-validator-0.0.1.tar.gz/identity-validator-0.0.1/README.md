# Simple package that validates if the identification document number typed by a user is right.

# Especifications:
Python3.7+

# Installation:
Just run 'pip install identity-validator' or 'python3 -m pip install identity-validator'. 

# Usage:
from identity-validator import Validator as valid.

valid.is_valid(document_name, document_numeration) Both parameters must be strings and this will return or True or False.

# pypi download
type in pypi search bar'identity-validator' or go directly to:
https://pypi.org/project/identity-validator/0.0.1/
